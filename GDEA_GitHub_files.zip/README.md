# Grouped Budgeted Uncertainty DEA — Reproducibility

This repository contains the reproducibility notebook for the revised 3-input/3-output European-bank application.

## Files

- `GDEA_reproducibility.ipynb`: complete notebook, with the current main analysis, the 1,000 within-region random-partition experiment, and output validation.
- `requirements.txt`: Python dependencies.
- `data/`: create this folder locally and place the original supplementary workbook there. The workbook is not redistributed.

## Data

The notebook expects:

`data/1-s2.0-S2352340918314410-mmc2.xlsx`

Obtain the workbook from the source publication's supplementary materials. Verify its terms before redistributing it.

## Reproduction

```bash
python -m pip install -r requirements.txt
jupyter lab GDEA_reproducibility.ipynb
```

Run the notebook cells in order. The main analysis evaluates all 12 combinations of `delta` and `Gamma_G` for GBU, product-calibrated flat BS, and the local-only comparator. The random-partition experiment is a separate, computationally intensive run with checkpoints and a fixed seed.

The final validation cell checks the expected record counts and packages generated results. Do not commit the source workbook or generated result archives unless the data license and repository policy permit it.

## Reproducibility notes

- The analysis uses the HiGHS LP solver through `scipy.optimize.linprog`.
- Random seeds and experiment settings are defined explicitly in the notebook.
- The country-to-region mapping is stated in the code; confirm it against the source documentation before publication.
- The notebook reports the Proposition 6 support-equality diagnostic using the solver-selected optimal intensity vectors.
