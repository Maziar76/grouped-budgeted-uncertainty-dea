# Two-Level GBU Robust BCC DEA: European Banks

Reproducible code for the empirical comparison of a two-level grouped budgeted uncertainty (GBU) model and a single-level Bertsimas–Sim (BS) robust BCC DEA model.

## Repository contents

```text
.
├── GDEA_GitHub.ipynb       # Clean Jupyter entry-point notebook
├── run_gbu_dea.py          # Complete analysis implementation
├── requirements.txt        # Python dependencies
├── data/
│   └── README.md           # Instructions for obtaining the input workbook
└── results/                # Generated outputs (not tracked by Git)
```

## Requirements

- Python 3.10 or later
- NumPy
- pandas
- SciPy (the LPs are solved with SciPy's HiGHS interface)
- openpyxl

Install the dependencies:

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## Input data

Download the original supplementary workbook and place it at:

```text
data/1-s2.0-S2352340918314410-mmc2(1).xlsx
```

The workbook is intentionally not bundled. Check the original source's terms of use before redistributing it. The script reads the first worksheet.

## Run

From the repository root:

```bash
python run_gbu_dea.py
```

Or open `GDEA_GitHub.ipynb` in Jupyter and run its analysis cell. The notebook calls the same script, so the notebook and command-line workflows do not maintain separate copies of the model.

## Main settings

Edit the configuration block near the beginning of `run_gbu_dea.py`:

- `DELTAS = [0.01, 0.025, 0.05]`
- `GAMMA_LOCAL = 1.0`
- `GAMMA_GLOBALS = [1.0, 2.0, 3.0, 5.0]`
- `QUICK_TEST = False`
- `BOOTSTRAP_REPS = 5000`
- `BOOTSTRAP_SEED = 20261117`

`QUICK_TEST=True` runs a reduced diagnostic sample and must not be used to report empirical results.

## Model specification implemented

- Input-oriented variable-returns-to-scale (BCC) DEA.
- Separate regional group frontiers and a pooled metafrontier.
- Country-level local uncertainty groups and a global activation budget.
- Upward-only uncertainty on reference inputs.
- Fixed target-bank observations and nominal output constraints.
- A single-level BS comparator with the same uncertainty radius and numerical global budget.

The GBU and BS uncertainty sets have different structures. Their results are compared under matched numerical settings; this does not assert that the uncertainty sets are identical or nested.

## Interpretation and inference

Robust scores are input expansion factors and can exceed one. The country-cluster bootstrap resamples country clusters while holding the estimated DEA scores fixed. It quantifies sampling variation in the paired score differences but does not re-estimate the DEA frontiers, so it is not a full DEA bootstrap.

## Outputs

Results are written to:

```text
results/TwoLevel_GBU_DEA_Results/
```

The output directory contains bank-level scores, Proposition 6 support-function checks, summary tables, ranking diagnostics, monotonicity diagnostics, country-level comparisons, and the country-cluster bootstrap results. An Excel workbook combines the principal tables.

## Reproducibility notes

- The bootstrap seed is fixed in the configuration.
- The LP solver is SciPy's HiGHS backend.
- The input workbook is an external dependency and is not included.
- The code validates the expected sample size and regional sample counts before running.
- Numerical results should be regenerated from the source workbook and this code; notebook outputs from the Deepnote working session have been cleared.

## Citation

If you use this code or its results, cite the associated manuscript and the original data source. Add the final bibliographic details and a repository license before making the repository public.
