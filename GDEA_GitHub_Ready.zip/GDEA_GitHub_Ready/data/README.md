# Input data

Place the original supplementary workbook in this directory:

`1-s2.0-S2352340918314410-mmc2(1).xlsx`

The analysis reads the first worksheet and expects 250 bank observations, with the country and bank identifiers and the input/output columns specified in `run_gbu_dea.py`.

The workbook is not included in this repository. Obtain it from the original data source and verify its terms of use before redistributing it. Do not rename the workbook unless you also update `SOURCE_FILE` near the top of `run_gbu_dea.py`.
