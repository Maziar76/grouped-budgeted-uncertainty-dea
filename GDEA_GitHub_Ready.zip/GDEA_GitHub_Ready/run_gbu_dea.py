# =====================================================================
# TWO-LEVEL GBU VS SINGLE-LEVEL BS ROBUST BCC DEA: EUROPEAN BANKS (2015)
#
# This is an END-TO-END replacement for the previous validation-only code.
# It reads the original 250-bank supplementary workbook, estimates:
#   (i) conventional input-oriented BCC group and metafrontier scores;
#  (ii) two-level GBU robust BCC scores for both frontiers;
# (iii) rankings, TGRs, monotonicity and consistency diagnostics.
#
# Grouping for the uncertainty set:
#   - Uncertainty groups are COUNTRIES (not the four regional frontiers).
#   - Within each country: local budget Gamma_local.
#   - Across countries: global activation budget Gamma_global.
#   - Regional DEA frontiers use the countries inside that region.
#   - The pooled metafrontier uses all 23 country groups.
#
# Model:
#   min theta
#   sum_j x_kj lambda_j + delta * beta_GBU((x_kj lambda_j)_j)
#       <= theta*x_ko                         for each input k
#   sum_j y_rj lambda_j >= y_ro               for each output r
#   sum_j lambda_j = 1, lambda >= 0
#
# Outputs are held fixed, matching the earlier empirical specification.
# Uncertainty is upward-only on reference inputs.
#
# Dependencies: numpy, pandas, scipy, openpyxl
# =====================================================================

import os
import re
import time
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

warnings.filterwarnings("ignore", category=RuntimeWarning)

# ----------------------------- SETTINGS ------------------------------

SOURCE_FILE = "1-s2.0-S2352340918314410-mmc2(1).xlsx"
OUTPUT_DIR = str(Path("results") / "TwoLevel_GBU_DEA_Results")

EXPECTED_N = 250
EXPECTED_REGION_COUNTS = {
    "Eastern Europe": 22,
    "Northern Europe": 33,
    "Southern Europe": 66,
    "Western Europe": 129,
}

# Primary 3-input / 3-output specification, matching the manuscript's
# intended primary specification. The workbook's actual output label is
# "Net Income Revenue (O)".
INPUT_COLS = [
    " Employees (I)",
    "Assets (I)",
    "Personnel Expenses (I)",
]
OUTPUT_COLS = [
    "Loans (O)",
    "Net Income Revenue (O)",
    "Net Fees Commission (O)",
]

# Country grouping is the second-level partition of uncertain reference
# coefficients. The four regions remain the separate group frontiers.
COUNTRY_TO_REGION = {
    "Czech Republic": "Eastern Europe",
    "Hungary": "Eastern Europe",
    "Poland": "Eastern Europe",
    "Romania": "Eastern Europe",
    "Slovakia": "Eastern Europe",
    "Slovenia": "Eastern Europe",
    "Denmark": "Northern Europe",
    "Finland": "Northern Europe",
    "Ireland": "Northern Europe",
    "Sweden": "Northern Europe",
    "United Kingdom": "Northern Europe",
    "Croatia": "Southern Europe",
    "Cyprus": "Southern Europe",
    "Greece": "Southern Europe",
    "Italy": "Southern Europe",
    "Portugal": "Southern Europe",
    "Spain": "Southern Europe",
    "Austria": "Western Europe",
    "Belgium": "Western Europe",
    "France": "Western Europe",
    "Germany": "Western Europe",
    "Luxembourg": "Western Europe",
    "Netherlands": "Western Europe",
}

# Sensitivity grid: 12 scenarios. Local budget is fixed at one deviation
# per active country; global budget controls how many country groups can
# be activated (fractionally) in the worst case.
DELTAS = [0.01, 0.025, 0.05]
GAMMA_LOCAL = 1.0
GAMMA_GLOBALS = [1.0, 2.0, 3.0, 5.0]

# For a lighter initial test, set QUICK_TEST=True. It estimates a subset
# of banks only; do NOT use quick-test outputs in a paper.
QUICK_TEST = False
QUICK_TEST_N_PER_REGION = 2

LP_METHOD = "highs"
LP_OPTIONS = {"presolve": True}
TOL = 1e-7
BOOTSTRAP_REPS = 5000
BOOTSTRAP_SEED = 20261117

# ------------------------------ HELPERS ------------------------------

def find_file(filename):
    """Locate the source workbook in the project root or data/ directory."""
    candidates = (
        Path(filename),
        Path("data") / filename,
    )
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate.resolve())
    return None


def clean_text(x):
    return re.sub(r"\s+", " ", str(x)).strip()


def scenario_tag(delta, gamma_global):
    # Compatible with the old scenario-column naming convention.
    d = f"{100*delta:.1f}".replace(".", "p")
    g = f"{gamma_global:g}".replace(".", "p")
    return f"D{d}_G{g}"


def proposition6_support_values(a, group_codes, p, rtol=1e-8, atol=1e-10):
    """Compute Proposition 6 GBU and flat-BS support values."""
    a = np.asarray(a, dtype=float)
    group_codes = np.asarray(group_codes)
    if a.ndim != 1 or group_codes.ndim != 1 or len(a) != len(group_codes):
        raise ValueError("a and group_codes must be equally sized one-dimensional arrays.")
    if not np.all(np.isfinite(a)) or np.any(a < -1e-10):
        raise ValueError("Proposition 6 requires finite nonnegative coefficients.")
    if int(p) != p or p < 1:
        raise ValueError("p must be a positive integer.")
    unique_groups = np.unique(group_codes)
    if p > len(unique_groups):
        raise ValueError("p cannot exceed the number of country groups.")
    a = np.maximum(a, 0.0)
    beta_bs = float(np.sort(a)[-int(p):].sum())
    maxima = np.array([a[group_codes == g].max() for g in unique_groups])
    beta_gbu = float(np.sort(maxima)[-int(p):].sum())
    return beta_gbu, beta_bs, bool(np.isclose(beta_gbu, beta_bs, rtol=rtol, atol=atol))


def solve_bcc(X, Y, x_target, y_target, group_codes,
              delta=0.0, gamma_local=1.0, gamma_global=0.0,
              uncertainty_model="GBU"):
    """Solve input-oriented BCC with GBU or ordinary BS uncertainty.

    GBU: country-local budgets Gamma_local plus global activation budget.
    BS: one flat Bertsimas-Sim budget Gamma_global over all reference banks.
    Both use the same relative upward input-deviation radius delta.
    """
    """
    Solve one input-oriented BCC model.

    X: n x m positive reference-input matrix.
    Y: n x s positive reference-output matrix.
    x_target: m-vector of target inputs.
    y_target: s-vector of target outputs.
    group_codes: length-n integer array identifying country groups.

    For delta > 0, the exact LP dual of the two-level GBU support
    function is embedded in the BCC LP. All uncertainty auxiliary
    variables are nonnegative.
    """
    n, m = X.shape
    nY, s = Y.shape
    if n != nY:
        raise ValueError("X and Y have different reference sample sizes.")
    if len(group_codes) != n:
        raise ValueError("group_codes length does not match reference sample.")
    if np.any(X <= 0) or np.any(Y <= 0):
        raise ValueError("This implementation expects strictly positive data.")

    groups = np.unique(group_codes)
    K = len(groups)
    group_to_pos = {g: h for h, g in enumerate(groups)}
    local_group = np.array([group_to_pos[g] for g in group_codes], dtype=int)

    # Variable layout:
    # theta, lambda[0:n], then for each input k:
    # rho_k, v_{kg}[0:K], pi_{kg}[0:K], w_{kj}[0:n].
    next_var = 0
    theta_idx = next_var
    next_var += 1
    lam_idx = np.arange(next_var, next_var + n)
    next_var += n

    support = []
    if uncertainty_model not in {"GBU", "BS"}:
        raise ValueError("uncertainty_model must be 'GBU' or 'BS'.")
    if delta > 0:
        for k in range(m):
            rho = next_var
            next_var += 1
            if uncertainty_model == "GBU":
                v = np.arange(next_var, next_var + K)
                next_var += K
                pi = np.arange(next_var, next_var + K)
                next_var += K
            else:
                v = pi = None
            w = np.arange(next_var, next_var + n)
            next_var += n
            support.append((rho, v, pi, w))

    nvars = next_var
    c = np.zeros(nvars)
    c[theta_idx] = 1.0

    ub_r, ub_c, ub_v, b_ub = [], [], [], []

    def add_ub(coeffs, rhs=0.0):
        row = len(b_ub)
        for col, val in coeffs.items():
            if abs(val) > 0:
                ub_r.append(row)
                ub_c.append(int(col))
                ub_v.append(float(val))
        b_ub.append(float(rhs))

    # Input constraints.
    for k in range(m):
        coeff = {lam_idx[j]: X[j, k] for j in range(n)}
        coeff[theta_idx] = -float(x_target[k])

        if delta > 0:
            rho, v, pi, w = support[k]
            if uncertainty_model == "GBU":
                coeff[rho] = float(gamma_global)
                for g in range(K):
                    coeff[v[g]] = 1.0
                add_ub(coeff, 0.0)

                # v_g >= Gamma_local*pi_g + sum_{j in g}w_j - rho
                for g in range(K):
                    group_members = np.flatnonzero(local_group == g)
                    row_coeff = {pi[g]: float(gamma_local), rho: -1.0, v[g]: -1.0}
                    for j in group_members:
                        row_coeff[w[j]] = 1.0
                    add_ub(row_coeff, 0.0)

                # w_j >= delta*X[j,k]*lambda_j - pi_{g(j)}
                for j in range(n):
                    g = local_group[j]
                    add_ub({lam_idx[j]: float(delta * X[j, k]),
                            pi[g]: -1.0, w[j]: -1.0}, 0.0)
            else:
                # Ordinary single-level BS support: Gamma*rho + sum_j w_j
                # with w_j >= delta*X[j,k]*lambda_j - rho.
                coeff[rho] = float(gamma_global)
                for j in range(n):
                    coeff[w[j]] = 1.0
                    add_ub({lam_idx[j]: float(delta * X[j, k]),
                            rho: -1.0, w[j]: -1.0}, 0.0)
                add_ub(coeff, 0.0)
        else:
            add_ub(coeff, 0.0)

    # Output constraints: sum_j Y[j,r]*lambda_j >= y_target[r].
    for r in range(s):
        coeff = {lam_idx[j]: -Y[j, r] for j in range(n)}
        add_ub(coeff, -float(y_target[r]))

    A_ub = coo_matrix(
        (ub_v, (ub_r, ub_c)),
        shape=(len(b_ub), nvars)
    ).tocsr()
    b_ub = np.asarray(b_ub, dtype=float)

    # VRS convexity: sum lambda = 1.
    eq_r = np.zeros(n, dtype=int)
    eq_c = lam_idx.astype(int)
    eq_v = np.ones(n, dtype=float)
    A_eq = coo_matrix((eq_v, (eq_r, eq_c)), shape=(1, nvars)).tocsr()
    b_eq = np.array([1.0])

    bounds = [(0.0, None)] * nvars

    result = linprog(
        c,
        A_ub=A_ub,
        b_ub=b_ub,
        A_eq=A_eq,
        b_eq=b_eq,
        bounds=bounds,
        method=LP_METHOD,
        options=LP_OPTIONS,
    )

    if not result.success:
        return {
            "score": np.nan,
            "status": int(result.status),
            "message": str(result.message),
            "nit": getattr(result, "nit", np.nan),
        }

    return {
        "score": float(result.x[theta_idx]),
        "lambda": result.x[lam_idx].copy(),
        "status": 0,
        "message": "optimal",
        "nit": getattr(result, "nit", np.nan),
    }


def prepare_frontier_matrices(data, indices, input_cols, output_cols):
    sub = data.iloc[indices].copy()
    X = sub[input_cols].to_numpy(dtype=float)
    Y = sub[output_cols].to_numpy(dtype=float)
    # Country groups are encoded locally within this frontier.
    codes, uniques = pd.factorize(sub["COUNTRY"], sort=True)
    return sub, X, Y, codes.astype(int), list(uniques)


def rank_corr(a, b):
    return pd.Series(a).rank(method="average").corr(
        pd.Series(b).rank(method="average"), method="pearson"
    )


def decile_overlap(a, b, best_is_high=False):
    a = pd.Series(np.asarray(a))
    b = pd.Series(np.asarray(b))
    n = len(a)
    k = max(1, int(np.ceil(0.10 * n)))
    if best_is_high:
        aa, bb = set(a.nlargest(k).index), set(b.nlargest(k).index)
        aw, bw = set(a.nsmallest(k).index), set(b.nsmallest(k).index)
    else:
        aa, bb = set(a.nsmallest(k).index), set(b.nsmallest(k).index)
        aw, bw = set(a.nlargest(k).index), set(b.nlargest(k).index)
    return len(aa & bb) / k, len(aw & bw) / k


# --------------------------- LOAD DATA --------------------------------

os.makedirs(OUTPUT_DIR, exist_ok=True)
source_path = find_file(SOURCE_FILE)
if source_path is None:
    raise FileNotFoundError(
        f"Cannot find {SOURCE_FILE}. Put the original supplementary XLSX "
        "in the project root or the data/ directory."
    )

print("=" * 78)
print("TWO-LEVEL GBU ROBUST BCC DEA: EUROPEAN BANKS")
print("=" * 78)
print("Source:", source_path)

data = pd.read_excel(source_path, sheet_name=0)
data.columns = [clean_text(c) for c in data.columns]

# Match the workbook's actual column names after whitespace normalization.
INPUT_COLS = [clean_text(c) for c in INPUT_COLS]
OUTPUT_COLS = [clean_text(c) for c in OUTPUT_COLS]

required = ["BANKS", "COUNTRY"] + INPUT_COLS + OUTPUT_COLS
missing = [c for c in required if c not in data.columns]
if missing:
    raise ValueError(f"Missing source columns: {missing}")

data["BANKS"] = data["BANKS"].map(clean_text)
data["COUNTRY"] = data["COUNTRY"].map(clean_text)
data["REGION"] = data["COUNTRY"].map(COUNTRY_TO_REGION)

if data["REGION"].isna().any():
    bad = sorted(data.loc[data["REGION"].isna(), "COUNTRY"].unique())
    raise ValueError(f"Countries lack a region mapping: {bad}")

if len(data) != EXPECTED_N:
    raise ValueError(f"Expected {EXPECTED_N} banks, found {len(data)}.")
if data["BANKS"].duplicated().any():
    raise ValueError("Duplicate bank names detected.")

for col in INPUT_COLS + OUTPUT_COLS:
    data[col] = pd.to_numeric(data[col], errors="coerce")
    if data[col].isna().any() or not np.isfinite(data[col]).all():
        raise ValueError(f"Missing/non-finite numeric data in {col}.")
    if (data[col] <= 0).any():
        raise ValueError(f"Nonpositive observations in {col}.")

counts = data["REGION"].value_counts().to_dict()
print("\nRegional sample sizes:")
for region, expected in EXPECTED_REGION_COUNTS.items():
    actual = counts.get(region, 0)
    print(f"  {region}: {actual} (expected {expected})")
    if actual != expected:
        raise ValueError(f"Region count mismatch for {region}: {actual}")

# Positive scale normalization by sample median; DEA scores are invariant
# to independent positive scaling of each input/output dimension.
scale = data[INPUT_COLS + OUTPUT_COLS].median()
data.loc[:, INPUT_COLS + OUTPUT_COLS] = (
    data[INPUT_COLS + OUTPUT_COLS] / scale
)

# Frontier index sets: one for each regional group frontier and one pooled.
frontiers = {}
for region in EXPECTED_REGION_COUNTS:
    frontiers[region] = np.flatnonzero(data["REGION"].to_numpy() == region)
frontiers["Pooled Metafrontier"] = np.arange(len(data))

# Optional smoke test: two banks per region. Do not report these as results.
if QUICK_TEST:
    selected = []
    for region in EXPECTED_REGION_COUNTS:
        idx = frontiers[region][:QUICK_TEST_N_PER_REGION]
        selected.extend(idx.tolist())
    eval_indices = sorted(set(selected))
else:
    eval_indices = list(range(len(data)))

print("\nUncertainty groups: countries.")
print("Local budget Gamma_local:", GAMMA_LOCAL)
print("Global budgets:", GAMMA_GLOBALS)
print("Uncertainty radii:", DELTAS)
print("Frontiers:", {k: len(v) for k, v in frontiers.items()})
print("Banks to evaluate:", len(eval_indices))

# ----------------------- ESTIMATE ALL DEA SCORES ----------------------

results = data[["BANKS", "COUNTRY", "REGION"]].copy()
results["Group_VRS"] = np.nan
results["Meta_VRS"] = np.nan
results["TGR_VRS"] = np.nan
results["Group_Status"] = ""
results["Meta_Status"] = ""

# Precompute each frontier's matrices and each bank's local target position.
frontier_cache = {}
for name, idx in frontiers.items():
    frontier_cache[name] = prepare_frontier_matrices(
        data, idx, INPUT_COLS, OUTPUT_COLS
    )

print("\n[1/3] Conventional BCC scores")
t0 = time.time()
for count, target_idx in enumerate(eval_indices, start=1):
    region = data.loc[target_idx, "REGION"]

    for frontier_name, output_col, status_col in [
        (region, "Group_VRS", "Group_Status"),
        ("Pooled Metafrontier", "Meta_VRS", "Meta_Status"),
    ]:
        sub, X, Y, codes, country_names = frontier_cache[frontier_name]
        loc = int(np.flatnonzero(sub.index.to_numpy() == target_idx)[0])
        sol = solve_bcc(
            X, Y, X[loc, :], Y[loc, :], codes,
            delta=0.0
        )
        results.loc[target_idx, output_col] = sol["score"]
        results.loc[target_idx, status_col] = sol["message"]

    if count % 25 == 0 or count == len(eval_indices):
        print(f"  {count}/{len(eval_indices)} banks; elapsed {time.time()-t0:.1f}s")

if not QUICK_TEST:
    results["TGR_VRS"] = results["Meta_VRS"] / results["Group_VRS"]

# ----------------------- TWO-LEVEL GBU SCENARIOS ----------------------

print("\n[2/3] Two-level GBU robust BCC scenarios")
scenario_metadata = []
for delta in DELTAS:
    for gamma_global in GAMMA_GLOBALS:
        tag = scenario_tag(delta, gamma_global)
        scenario_metadata.append({
            "tag": tag,
            "delta": delta,
            "Gamma_local": GAMMA_LOCAL,
            "Gamma_global": gamma_global,
        })
        for metric in ["Group", "Meta", "TGR"]:
            results[f"{tag}_{metric}"] = np.nan
        results[f"{tag}_Group_Status"] = ""
        results[f"{tag}_Meta_Status"] = ""

total = len(eval_indices) * len(scenario_metadata) * 2
done = 0
t0 = time.time()
proposition6_records = []

for scen in scenario_metadata:
    tag = scen["tag"]
    delta = scen["delta"]
    gamma_global = scen["Gamma_global"]
    print(
        f"\n  Scenario {tag}: delta={delta:.3%}, "
        f"Gamma_local={GAMMA_LOCAL:g}, Gamma_global={gamma_global:g}"
    )

    for target_idx in eval_indices:
        region = data.loc[target_idx, "REGION"]

        for frontier_name, metric, status_metric in [
            (region, "Group", f"{tag}_Group_Status"),
            ("Pooled Metafrontier", "Meta", f"{tag}_Meta_Status"),
        ]:
            sub, X, Y, codes, country_names = frontier_cache[frontier_name]
            loc = int(np.flatnonzero(sub.index.to_numpy() == target_idx)[0])

            sol = solve_bcc(
                X, Y, X[loc, :], Y[loc, :], codes,
                delta=delta,
                gamma_local=GAMMA_LOCAL,
                gamma_global=gamma_global,
            )
            results.loc[target_idx, f"{tag}_{metric}"] = sol["score"]
            results.loc[target_idx, status_metric] = sol["message"]

            # The support coefficient for reference bank j and input k is
            # delta * X[j,k] * lambda[j] at this optimal GBU solution.
            if sol.get("lambda") is not None and float(gamma_global).is_integer():
                lam_opt = np.asarray(sol["lambda"], dtype=float)
                p = int(gamma_global)
                for k, input_name in enumerate(INPUT_COLS):
                    a_vec = delta * X[:, k] * lam_opt
                    beta_gbu, beta_bs, equal = proposition6_support_values(
                        a_vec, codes, p
                    )
                    proposition6_records.append({
                        "Bank": data.loc[target_idx, "BANKS"],
                        "Country": data.loc[target_idx, "COUNTRY"],
                        "Region": region,
                        "Frontier": frontier_name,
                        "Input": input_name,
                        "Delta": delta,
                        "Gamma_local": GAMMA_LOCAL,
                        "Global_Budget_p": p,
                        "GBU_Support": beta_gbu,
                        "BS_Support": beta_bs,
                        "Support_Difference_BS_minus_GBU": beta_bs - beta_gbu,
                        "Equality": equal,
                        "N_Country_Groups": int(pd.Series(codes).nunique()),
                    })
            done += 1

        if done % 100 == 0:
            print(
                f"    LPs {done}/{total}; "
                f"elapsed {time.time()-t0:.1f}s"
            )

    if not QUICK_TEST:
        results[f"{tag}_TGR"] = (
            results[f"{tag}_Meta"] / results[f"{tag}_Group"]
        )

# -------------------- SINGLE-LEVEL BS COMPARATOR ---------------------
# Match delta and the global budget Gamma_global. The flat BS uncertainty
# set has one budget over all reference-bank coefficients; it does not use
# country partitions or local budgets.
print("\n[3/4] Single-level BS comparator")
for scen in scenario_metadata:
    tag = scen["tag"]
    delta = scen["delta"]
    gamma = scen["Gamma_global"]
    for metric in ["Group", "Meta"]:
        results[f"{tag}_BS_{metric}"] = np.nan
        results[f"{tag}_BS_{metric}_Status"] = ""
    for target_idx in eval_indices:
        region = data.loc[target_idx, "REGION"]
        for frontier_name, metric in [(region, "Group"), ("Pooled Metafrontier", "Meta")]:
            sub, X, Y, codes, country_names = frontier_cache[frontier_name]
            loc = int(np.flatnonzero(sub.index.to_numpy() == target_idx)[0])
            sol = solve_bcc(
                X, Y, X[loc, :], Y[loc, :], codes,
                delta=delta, gamma_global=gamma, uncertainty_model="BS"
            )
            results.loc[target_idx, f"{tag}_BS_{metric}"] = sol["score"]
            results.loc[target_idx, f"{tag}_BS_{metric}_Status"] = sol["message"]
    if not QUICK_TEST:
        results[f"{tag}_BS_TGR"] = results[f"{tag}_BS_Meta"] / results[f"{tag}_BS_Group"]

# Fail loudly if any requested solve did not return an optimum.
score_cols = ["Group_VRS", "Meta_VRS"] + [
    f"{s['tag']}_{metric}"
    for s in scenario_metadata
    for metric in ["Group", "Meta"]
] + [
    f"{s['tag']}_BS_{metric}"
    for s in scenario_metadata
    for metric in ["Group", "Meta"]
]
if not QUICK_TEST:
    bad = results[score_cols].isna().sum()
    bad = bad[bad > 0]
    if len(bad):
        raise RuntimeError(
            "Some DEA LPs did not return optimal scores:\n" + bad.to_string()
        )

# ----------------------- SUMMARY / VALIDATION -------------------------

print("\n[4/4] Building validation, ranking, and model-comparison summaries")
summary_rows = []
regional_rows = []
rank_rows = []
monotonicity_rows = []

if not QUICK_TEST:
    for scen in scenario_metadata:
        tag = scen["tag"]
        g = results[f"{tag}_Group"]
        m = results[f"{tag}_Meta"]
        t = results[f"{tag}_TGR"]
        summary_rows.append({
            "Delta": scen["delta"],
            "Gamma_local": scen["Gamma_local"],
            "Gamma_global": scen["Gamma_global"],
            "Group_Mean": g.mean(),
            "Group_Median": g.median(),
            "Group_SD": g.std(),
            "Meta_Mean": m.mean(),
            "Meta_Median": m.median(),
            "Meta_SD": m.std(),
            "TGR_Mean": t.mean(),
            "TGR_Median": t.median(),
            "TGR_SD": t.std(),
            "Group_Increased_Count": int((g > results["Group_VRS"] + TOL).sum()),
            "Meta_Increased_Count": int((m > results["Meta_VRS"] + TOL).sum()),
            "Meta_Above_Group_Count": int((m > g + 1e-5).sum()),
            "TGR_Max_Absolute_Error": float((t - m / g).abs().max()),
        })

        for region, sub in results.groupby("REGION", sort=True):
            rho = rank_corr(sub["Group_VRS"], sub[f"{tag}_Group"])
            best, worst = decile_overlap(
                sub["Group_VRS"].reset_index(drop=True),
                sub[f"{tag}_Group"].reset_index(drop=True),
                best_is_high=False,
            )
            rank_rows.append({
                "Delta": scen["delta"],
                "Gamma_local": scen["Gamma_local"],
                "Gamma_global": scen["Gamma_global"],
                "Scope": "Group",
                "Region": region,
                "N": len(sub),
                "Spearman": rho,
                "Best_Decile_Overlap_Rate": best,
                "Worst_Decile_Overlap_Rate": worst,
            })

        for scope, base_col, robust_col, high in [
            ("Meta", "Meta_VRS", f"{tag}_Meta", False),
            ("TGR", "TGR_VRS", f"{tag}_TGR", True),
        ]:
            rho = rank_corr(results[base_col], results[robust_col])
            best, worst = decile_overlap(
                results[base_col].reset_index(drop=True),
                results[robust_col].reset_index(drop=True),
                best_is_high=high,
            )
            rank_rows.append({
                "Delta": scen["delta"],
                "Gamma_local": scen["Gamma_local"],
                "Gamma_global": scen["Gamma_global"],
                "Scope": scope,
                "Region": "All banks",
                "N": len(results),
                "Spearman": rho,
                "Best_Decile_Overlap_Rate": best,
                "Worst_Decile_Overlap_Rate": worst,
            })

    # Regional score summary for conventional and one reference scenario.
    reference_tag = scenario_tag(0.025, 5.0)
    for region, sub in results.groupby("REGION", sort=True):
        regional_rows.append({
            "Region": region,
            "N": len(sub),
            "Conventional_Group_Mean": sub["Group_VRS"].mean(),
            "Conventional_Meta_Mean": sub["Meta_VRS"].mean(),
            "Conventional_TGR_Mean": sub["TGR_VRS"].mean(),
            "GBU_Group_Mean": sub[f"{reference_tag}_Group"].mean(),
            "GBU_Meta_Mean": sub[f"{reference_tag}_Meta"].mean(),
            "GBU_TGR_Mean": sub[f"{reference_tag}_TGR"].mean(),
            "Reference_Scenario": reference_tag,
            "Gamma_local": GAMMA_LOCAL,
        })

    # Monotonicity in global budget, for each fixed delta.
    for delta in DELTAS:
        tags = [scenario_tag(delta, gg) for gg in GAMMA_GLOBALS]
        for metric in ["Group", "Meta"]:
            for a, b in zip(tags[:-1], tags[1:]):
                change = results[f"{b}_{metric}"] - results[f"{a}_{metric}"]
                monotonicity_rows.append({
                    "Metric": metric,
                    "Delta": delta,
                    "Comparison": "Increasing global budget",
                    "From": a,
                    "To": b,
                    "Decreases": int((change < -TOL).sum()),
                    "Unchanged": int((change.abs() <= TOL).sum()),
                    "Increases": int((change > TOL).sum()),
                    "Minimum_Change": float(change.min()),
                })

    # Monotonicity in uncertainty radius, for each fixed global budget.
    for gamma in GAMMA_GLOBALS:
        tags = [scenario_tag(dd, gamma) for dd in DELTAS]
        for metric in ["Group", "Meta"]:
            for a, b in zip(tags[:-1], tags[1:]):
                change = results[f"{b}_{metric}"] - results[f"{a}_{metric}"]
                monotonicity_rows.append({
                    "Metric": metric,
                    "Gamma_global": gamma,
                    "Comparison": "Increasing uncertainty radius",
                    "From": a,
                    "To": b,
                    "Decreases": int((change < -TOL).sum()),
                    "Unchanged": int((change.abs() <= TOL).sum()),
                    "Increases": int((change > TOL).sum()),
                    "Minimum_Change": float(change.min()),
                })

# Direct paired comparison: two-level GBU minus single-level BS.
comparison_rows = []
bank_comparison_rows = []
frontier_group_diagnostics = []
if not QUICK_TEST:
    for scen in scenario_metadata:
        tag = scen["tag"]
        for scope, gbu_col, bs_col in [
            ("Group", f"{tag}_Group", f"{tag}_BS_Group"),
            ("Meta", f"{tag}_Meta", f"{tag}_BS_Meta"),
            ("TGR", f"{tag}_TGR", f"{tag}_BS_TGR"),
        ]:
            diff = results[gbu_col] - results[bs_col]
            comparison_rows.append({
                "Delta": scen["delta"], "Gamma_local": GAMMA_LOCAL,
                "Gamma_global": scen["Gamma_global"], "Scope": scope,
                "GBU_Mean": results[gbu_col].mean(), "BS_Mean": results[bs_col].mean(),
                "Mean_GBU_minus_BS": diff.mean(), "Median_GBU_minus_BS": diff.median(),
                "SD_Difference": diff.std(), "Mean_Absolute_Difference": diff.abs().mean(),
                "GBU_Higher_Count": int((diff > TOL).sum()),
                "BS_Higher_Count": int((diff < -TOL).sum()),
                "Equal_Count": int((diff.abs() <= TOL).sum()),
                "Spearman_Rank": rank_corr(results[gbu_col], results[bs_col]),
            })
        # Bank-level differences for detailed investigation.
        for i, row in results.iterrows():
            bank_comparison_rows.append({
                "BANKS": row["BANKS"], "COUNTRY": row["COUNTRY"], "REGION": row["REGION"],
                "Scenario": tag, "Delta": scen["delta"],
                "Gamma_local": GAMMA_LOCAL, "Gamma_global": scen["Gamma_global"],
                "Group_GBU": row[f"{tag}_Group"], "Group_BS": row[f"{tag}_BS_Group"],
                "Group_Difference": row[f"{tag}_Group"] - row[f"{tag}_BS_Group"],
                "Meta_GBU": row[f"{tag}_Meta"], "Meta_BS": row[f"{tag}_BS_Meta"],
                "Meta_Difference": row[f"{tag}_Meta"] - row[f"{tag}_BS_Meta"],
                "TGR_GBU": row[f"{tag}_TGR"], "TGR_BS": row[f"{tag}_BS_TGR"],
                "TGR_Difference": row[f"{tag}_TGR"] - row[f"{tag}_BS_TGR"],
            })

    # Number of country groups and effective global-budget saturation.
    for frontier_name, idx in frontiers.items():
        sub = data.iloc[idx]
        K = int(sub["COUNTRY"].nunique())
        for gamma in GAMMA_GLOBALS:
            frontier_group_diagnostics.append({
                "Frontier": frontier_name, "N_Banks": len(sub),
                "Country_Groups_K": K, "Gamma_global": gamma,
                "Gamma_vs_K": gamma / K,
                "Global_Budget_Reaches_All_Groups": bool(gamma >= K),
                "Effective_Activation_Cap": min(gamma, float(K)),
            })

comparison = pd.DataFrame(comparison_rows)
bank_comparison = pd.DataFrame(bank_comparison_rows)
frontier_diagnostics = pd.DataFrame(frontier_group_diagnostics)

# ---------------- COUNTRY HETEROGENEITY, DECILE OVERLAP, BOOTSTRAP --------
# Bootstrap resamples observed country clusters while holding the DEA scores
# fixed. This quantifies sampling variation in the paired score differences;
# it is NOT a full DEA bootstrap because frontiers are not re-estimated.
rng = np.random.default_rng(BOOTSTRAP_SEED)
country_rows = []
bs_rank_rows = []
bootstrap_rows = []

if not QUICK_TEST:
    # Country-level heterogeneity in the paired GBU-minus-BS differences.
    for scen in scenario_metadata:
        tag = scen["tag"]
        for scope, diff_col in [
            ("Group", "Group_Difference"),
            ("Meta", "Meta_Difference"),
            ("TGR", "TGR_Difference"),
        ]:
            block = bank_comparison[bank_comparison["Scenario"] == tag]
            for country, csub in block.groupby("COUNTRY", sort=True):
                vals = csub[diff_col].to_numpy(dtype=float)
                country_rows.append({
                    "Scenario": tag, "Delta": scen["delta"],
                    "Gamma_local": GAMMA_LOCAL,
                    "Gamma_global": scen["Gamma_global"],
                    "Scope": scope, "Country": country, "N_Banks": len(vals),
                    "Mean_GBU_minus_BS": float(np.mean(vals)),
                    "Median_GBU_minus_BS": float(np.median(vals)),
                    "Min_Difference": float(np.min(vals)),
                    "Max_Difference": float(np.max(vals)),
                    "GBU_Lower_Count": int((vals < -TOL).sum()),
                    "Equal_Count": int((np.abs(vals) <= TOL).sum()),
                    "GBU_Higher_Count": int((vals > TOL).sum()),
                })

        # Direct ranking consequences of GBU versus BS, using the same
        # score orientation as in the conventional-vs-GBU ranking table.
        for scope, gbu_col, bs_col, high in [
            ("Group", f"{tag}_Group", f"{tag}_BS_Group", False),
            ("Meta", f"{tag}_Meta", f"{tag}_BS_Meta", False),
            ("TGR", f"{tag}_TGR", f"{tag}_BS_TGR", True),
        ]:
            if scope == "Group":
                rank_blocks = [(region, results[results["REGION"] == region])
                               for region in EXPECTED_REGION_COUNTS]
            else:
                rank_blocks = [("All banks", results)]
            for label, sub in rank_blocks:
                a = sub[gbu_col].reset_index(drop=True)
                b = sub[bs_col].reset_index(drop=True)
                best, worst = decile_overlap(a, b, best_is_high=high)
                bs_rank_rows.append({
                    "Scenario": tag, "Delta": scen["delta"],
                    "Gamma_local": GAMMA_LOCAL,
                    "Gamma_global": scen["Gamma_global"],
                    "Scope": scope, "Region": label, "N": len(sub),
                    "Spearman_GBU_vs_BS": rank_corr(a, b),
                    "Best_Decile_Overlap_Rate": best,
                    "Worst_Decile_Overlap_Rate": worst,
                })

    # Country-cluster bootstrap, stratified by regional frontier for Group
    # scores. Meta and TGR use all 23 country clusters. Each draw samples
    # countries with replacement and includes all banks in each selected
    # country; repeated draws retain multiplicity.
    for scen in scenario_metadata:
        tag = scen["tag"]
        for scope, diff_col in [
            ("Group", "Group_Difference"),
            ("Meta", "Meta_Difference"),
            ("TGR", "TGR_Difference"),
        ]:
            if scope == "Group":
                blocks = [(region, bank_comparison[
                    (bank_comparison["Scenario"] == tag) &
                    (bank_comparison["REGION"] == region)
                ]) for region in EXPECTED_REGION_COUNTS]
            else:
                blocks = [("All banks", bank_comparison[
                    bank_comparison["Scenario"] == tag
                ])]

            for label, block in blocks:
                clusters = [g[diff_col].to_numpy(dtype=float)
                            for _, g in block.groupby("COUNTRY", sort=True)]
                if not clusters or sum(len(x) for x in clusters) == 0:
                    continue
                observed = np.concatenate(clusters)
                boot_means = np.empty(BOOTSTRAP_REPS, dtype=float)
                for bidx in range(BOOTSTRAP_REPS):
                    chosen = rng.integers(0, len(clusters), size=len(clusters))
                    sample = np.concatenate([clusters[j] for j in chosen])
                    boot_means[bidx] = np.mean(sample)
                lo, hi = np.quantile(boot_means, [0.025, 0.975])
                bootstrap_rows.append({
                    "Scenario": tag, "Delta": scen["delta"],
                    "Gamma_local": GAMMA_LOCAL,
                    "Gamma_global": scen["Gamma_global"],
                    "Scope": scope, "Region": label,
                    "N_Banks": len(observed),
                    "N_Country_Clusters": len(clusters),
                    "Observed_Mean_GBU_minus_BS": float(np.mean(observed)),
                    "Bootstrap_Mean": float(np.mean(boot_means)),
                    "CI_2p5": float(lo), "CI_97p5": float(hi),
                    "Bootstrap_Reps": BOOTSTRAP_REPS,
                    "Bootstrap_Seed": BOOTSTRAP_SEED,
                    "CI_Excludes_Zero": bool(lo > 0 or hi < 0),
                    "Inference_Note": "Country-cluster bootstrap of fixed paired score differences; DEA frontiers not re-estimated.",
                })

country_heterogeneity = pd.DataFrame(country_rows)
gbu_bs_rankings = pd.DataFrame(bs_rank_rows)
cluster_bootstrap = pd.DataFrame(bootstrap_rows)

overall = pd.DataFrame(summary_rows)
regional = pd.DataFrame(regional_rows)
rankings = pd.DataFrame(rank_rows)
monotonicity = pd.DataFrame(monotonicity_rows)
scenario_table = pd.DataFrame(scenario_metadata)

# ---------------------- PROPOSITION 6 FREQUENCY ----------------------

proposition6_results = pd.DataFrame(proposition6_records)
if not proposition6_results.empty:
    proposition6_frequency = (
        proposition6_results
        .groupby(["Delta", "Global_Budget_p", "Frontier"], as_index=False)
        .agg(
            Number_of_Cases=("Equality", "size"),
            Equality_Cases=("Equality", "sum"),
            Mean_Support_Difference=("Support_Difference_BS_minus_GBU", "mean"),
            Median_Support_Difference=("Support_Difference_BS_minus_GBU", "median"),
        )
    )
    proposition6_frequency["Equality_Frequency_Percent"] = (
        100.0 * proposition6_frequency["Equality_Cases"]
        / proposition6_frequency["Number_of_Cases"]
    )
else:
    proposition6_frequency = pd.DataFrame()

# ------------------------------ SAVE ----------------------------------

scores_csv = os.path.join(OUTPUT_DIR, "TwoLevel_GBU_Bank_Scores.csv")
results.to_csv(scores_csv, index=False)
proposition6_results.to_csv(
    os.path.join(OUTPUT_DIR, "Proposition6_Cases.csv"), index=False
)
proposition6_frequency.to_csv(
    os.path.join(OUTPUT_DIR, "Proposition6_Equality_Frequency.csv"), index=False
)

if not QUICK_TEST:
    xlsx_out = os.path.join(OUTPUT_DIR, "TwoLevel_GBU_Empirical_Results.xlsx")
    with pd.ExcelWriter(xlsx_out, engine="openpyxl") as writer:
        results.to_excel(writer, sheet_name="Bank_Level_Scores", index=False)
        overall.to_excel(writer, sheet_name="Overall_Summary", index=False)
        regional.to_excel(writer, sheet_name="Regional_Summary", index=False)
        rankings.to_excel(writer, sheet_name="Ranking_Stability", index=False)
        monotonicity.to_excel(writer, sheet_name="Monotonicity", index=False)
        scenario_table.to_excel(writer, sheet_name="Scenario_Definitions", index=False)
        comparison.to_excel(writer, sheet_name="GBU_vs_BS_Summary", index=False)
        bank_comparison.to_excel(writer, sheet_name="GBU_vs_BS_Bank_Level", index=False)
        frontier_diagnostics.to_excel(writer, sheet_name="Frontier_Group_Diagnostics", index=False)
        country_heterogeneity.to_excel(writer, sheet_name="Country_Heterogeneity", index=False)
        gbu_bs_rankings.to_excel(writer, sheet_name="GBU_BS_Ranking_Overlap", index=False)
        cluster_bootstrap.to_excel(writer, sheet_name="Country_Cluster_Bootstrap", index=False)
        proposition6_results.to_excel(writer, sheet_name="Proposition6_Cases", index=False)
        proposition6_frequency.to_excel(writer, sheet_name="Proposition6_Frequency", index=False)

    overall.to_csv(os.path.join(OUTPUT_DIR, "Overall_Summary.csv"), index=False)
    regional.to_csv(os.path.join(OUTPUT_DIR, "Regional_Summary.csv"), index=False)
    rankings.to_csv(os.path.join(OUTPUT_DIR, "Ranking_Stability.csv"), index=False)
    monotonicity.to_csv(os.path.join(OUTPUT_DIR, "Monotonicity.csv"), index=False)
    comparison.to_csv(os.path.join(OUTPUT_DIR, "GBU_vs_BS_Summary.csv"), index=False)
    bank_comparison.to_csv(os.path.join(OUTPUT_DIR, "GBU_vs_BS_Bank_Level.csv"), index=False)
    frontier_diagnostics.to_csv(os.path.join(OUTPUT_DIR, "Frontier_Group_Diagnostics.csv"), index=False)
    country_heterogeneity.to_csv(os.path.join(OUTPUT_DIR, "Country_Heterogeneity.csv"), index=False)
    gbu_bs_rankings.to_csv(os.path.join(OUTPUT_DIR, "GBU_BS_Ranking_Overlap.csv"), index=False)
    cluster_bootstrap.to_csv(os.path.join(OUTPUT_DIR, "Country_Cluster_Bootstrap.csv"), index=False)

print("\n" + "=" * 78)
if QUICK_TEST:
    print("QUICK TEST COMPLETED (NOT PAPER-REPORTABLE)")
else:
    print("TWO-LEVEL GBU DEA COMPLETED")
print("=" * 78)
print("Uncertainty partition: country groups within each DEA reference frontier.")
print(f"Local budget: Gamma_local={GAMMA_LOCAL}")
print(f"Global budgets: {GAMMA_GLOBALS}")
print(f"Uncertainty radii: {DELTAS}")
print("Bank-level scores:", scores_csv)

if not QUICK_TEST:
    print("\nOverall results:")
    print(overall.to_string(index=False))
    print("\nRegional results at delta=2.5%, Gamma_global=5:")
    print(regional.to_string(index=False))
    print("\nRanking stability:")
    print(rankings.to_string(index=False))
    print("\nMonotonicity:")
    print(monotonicity.to_string(index=False))
    print("\nGBU versus single-level BS:")
    print(comparison.to_string(index=False))
    print("\nFrontier country-group diagnostics:")
    print(frontier_diagnostics.to_string(index=False))
    print("\nGBU versus BS ranking overlap:")
    print(gbu_bs_rankings.to_string(index=False))
    print("\nCountry-cluster bootstrap intervals (fixed-score inference):")
    print(cluster_bootstrap.to_string(index=False))
    print("\nCountry heterogeneity table saved:", os.path.join(OUTPUT_DIR, "Country_Heterogeneity.csv"))
    print("\nExcel workbook:", xlsx_out)
    print("\nProposition 6 equality frequencies:")
    print(proposition6_frequency.to_string(index=False))

print("\nImportant interpretation:")
print("- Country groups create the local/global two-level uncertainty hierarchy.")
print("- Regional frontiers are separate DEA technologies, not uncertainty groups.")
print("- Outputs and target-bank data are fixed; only reference inputs are uncertain.")
print("- Robust scores are input expansion factors and may exceed one.")
print("- BS comparator uses the same delta and flat Gamma_global budget.")
print("- GBU-vs-BS differences compare distinct uncertainty geometries, not identical sets.")
print("- Country-cluster intervals resample fixed paired differences; they do not re-estimate DEA frontiers.")
print("- No results are fabricated: all scores are computed by LPs from the XLSX.")
